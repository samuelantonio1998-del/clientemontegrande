# Correções HIGH PRIORITY — Cliente Qta. Monte Grande

Pacote com **13 ficheiros corrigidos** + **1 migration nova**, organizados na mesma estrutura do teu repo.

## Lista de ficheiros

```
output/
├── index.html                                      # Substituir (raíz do repo)
│
├── public/
│   ├── manifest.json                               # Novo — PWA manifest
│   └── robots.txt                                  # Substituir — bloqueia indexação
│
├── src/pages/
│   └── Privacy.tsx                                 # Substituir — RGPD completo
│
└── supabase/
    ├── functions/
    │   ├── _shared/
    │   │   └── cors.ts                             # Novo — helper CORS partilhado
    │   ├── register-meal/index.ts                  # Substituir — usa SQL atómico
    │   ├── redeem-benefit/index.ts                 # Substituir — status codes
    │   ├── delete-account/index.ts                 # Substituir — CORS restrito
    │   ├── submit-review/index.ts                  # Substituir — CORS restrito
    │   ├── verify-follow-screenshot/index.ts       # Substituir — CORS restrito
    │   ├── verify-google-review/index.ts           # Substituir — CORS restrito
    │   └── export-emails/index.ts                  # Substituir — CORS restrito
    │
    └── migrations/
        └── 20260513000000_register_meal_atomic.sql # Nova — função SQL atómica
```

---

## Ordem de aplicação recomendada

### Passo 1 — RGPD (5 minutos, sem risco)

1. Abre `src/pages/Privacy.tsx`
2. **OBRIGATÓRIO**: preenche o objeto `COMPANY` no topo do ficheiro com os dados reais:
   - `address`: morada completa da empresa
   - `nipc`: número de contribuinte (NIPC)
   - `email`: email de contacto para questões RGPD
   - `phone`: telefone (opcional — deixa string vazia se preferires)
3. Commit e deploy.

### Passo 2 — index.html, manifest, robots (10 minutos, sem risco)

1. Substitui `index.html` na raiz do repo.
2. Coloca `manifest.json` e `robots.txt` em `public/`.
3. **Adicional** — gera dois PNGs do logo e coloca em `public/`:
   - `apple-touch-icon.png` (180×180)
   - `icon-192.png` (192×192)
   - `icon-512.png` (512×512)
   - `og-image.webp` (1200×630) — preview ao colar URL em WhatsApp/etc.

   Se não gerares já, o site funciona — só não mostra ícones perfeitos quando "adicionado ao ecrã inicial".

4. Commit e deploy. Confirma na consola de rede do browser que **NÃO há erro 404 do preload** (era o problema que apontei).

### Passo 3 — Migration SQL atómica (15 minutos, **TESTAR PRIMEIRO**)

1. Coloca `20260513000000_register_meal_atomic.sql` em `supabase/migrations/`.
2. **Antes de fazer push para produção**, testa localmente:
   ```bash
   supabase db reset      # Reaplica todas as migrations num DB local
   ```
3. Se estás no Lovable e ele aplica migrations automaticamente: força um deploy e verifica no Supabase Dashboard → Database → Functions que aparece `register_meal_atomic`.

### Passo 4 — Edge functions (30 minutos)

**Ordem segura — deploya UMA de cada vez e testa antes de avançar:**

1. **`_shared/cors.ts`** — deploya primeiro (não é função, é dependência das outras)
2. **`register-meal/index.ts`** — testa registar uma refeição como admin
3. **`redeem-benefit/index.ts`** — testa resgatar desconto e buffet
4. **`delete-account/index.ts`** — testa criar conta de teste e apagar
5. **`submit-review/index.ts`** — testa submeter review
6. **`verify-follow-screenshot/index.ts`** — testa submeter screenshot
7. **`verify-google-review/index.ts`** — testa submeter screenshot de review
8. **`export-emails/index.ts`** — testa exportação CSV

**Como deployar no Lovable + Supabase:** o Lovable deteta alterações em `supabase/functions/*` e faz deploy automático após push. Se preferires manual:
```bash
supabase functions deploy register-meal --no-verify-jwt=false
```

---

## ⚠️ Frontend não foi alterado (intencional)

O frontend chama `supabase.functions.invoke(...)` com o cliente Supabase, que **trata automaticamente** dos novos status codes — devolve `{ error: ... }` no `data` ou no `error` consoante o caso. **Não precisas de alterar nada no frontend** para que os novos status codes funcionem.

**No entanto**, repara que no `Admin.tsx` o tratamento de erros faz só `data?.error === "cooldown_active"`. Com o novo status 429, isso continua a funcionar (porque o erro continua a vir no body), mas idealmente devias também tratar `error` (a propriedade ao lado de `data` que o invoke devolve). Não é bloqueante.

---

## Resumo das mudanças

| Ficheiro | O que mudou |
|---|---|
| `index.html` | `lang="pt-PT"`, removido preload partido, removidos TODOs, theme-color, manifest, apple-touch-icon, `noindex`, espaço antes do `!` corrigido, `<noscript>` fallback, OG no domínio próprio |
| `public/manifest.json` | Novo — PWA com cores certas, ícones, idioma PT |
| `public/robots.txt` | Bloqueia indexação total — apropriado para app de login |
| `src/pages/Privacy.tsx` | Contacto direto, morada, NIPC, link CNPD, secção sobre subcontratantes (Supabase/Lovable/Google), secção sobre transferências internacionais, secção sobre cookies/localStorage, direitos completos do RGPD |
| `supabase/functions/_shared/cors.ts` | **Novo** — helper único para CORS restrito + helpers para responder JSON e preflight |
| `supabase/functions/register-meal/index.ts` | Chama a nova função SQL atómica em vez de fazer cooldown check + insert separados; CORS restrito; status codes 401/403/404/429 corretos |
| `supabase/functions/redeem-benefit/index.ts` | Status codes corretos (401/403/404/409/500), CORS restrito, constantes `DISCOUNT_VALUE_EUR` e `BUFFET_POINTS_COST` no topo (já não hardcoded a 10/200 espalhados) |
| `supabase/functions/delete-account/index.ts` | CORS restrito |
| `supabase/functions/submit-review/index.ts` | CORS restrito |
| `supabase/functions/verify-follow-screenshot/index.ts` | CORS restrito |
| `supabase/functions/verify-google-review/index.ts` | CORS restrito |
| `supabase/functions/export-emails/index.ts` | CORS restrito |
| `supabase/migrations/20260513000000_register_meal_atomic.sql` | **Nova migration** — função SQL `register_meal_atomic` com `SELECT ... FOR UPDATE` para serializar chamadas concorrentes ao mesmo cliente |

---

## Notas finais

- **Funções cron NÃO foram alteradas**: `birthday-check`, `cleanup-unconfirmed`, `weekly-reset` continuam com `Origin: *` porque só são chamadas por cron schedulers (não-browser). Os seus `CRON_SECRET` já fazem a autenticação correta.
- **`check-rate-limit` já estava bem** (CORS restrito + status codes), não tocado.
- **`auth-email-hook` já estava bem** (verifica assinatura do webhook), não tocado.
- **`process-email-queue`** não tocado — só é chamado internamente.

Se algo correr mal num deploy, reverte só a function afetada — as outras são independentes.
