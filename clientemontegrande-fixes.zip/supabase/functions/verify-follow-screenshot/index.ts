import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";
import { jsonResponse, preflightResponse } from "../_shared/cors.ts";

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return preflightResponse(req);
  }

  try {
    const authHeader = req.headers.get("authorization");
    if (!authHeader) {
      return jsonResponse(req, { error: "Not authenticated" }, 401);
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Verify user
    const supabaseAuth = createClient(supabaseUrl, supabaseServiceKey);
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseAuth.auth.getUser(token);
    if (authError || !user) {
      return jsonResponse(req, { error: "Invalid token" }, 401);
    }

    let body: { screenshot_url?: string; claim_id?: string };
    try {
      body = await req.json();
    } catch {
      return jsonResponse(req, { error: "Invalid JSON" }, 400);
    }

    const { screenshot_url, claim_id } = body;
    if (!screenshot_url || !claim_id) {
      return jsonResponse(req, { error: "Missing parameters" }, 400);
    }

    // Generate a signed URL for the screenshot (bucket is private)
    const supabaseForStorage = createClient(supabaseUrl, supabaseServiceKey);
    const { data: signedUrlData } = await supabaseForStorage.storage
      .from("follow-screenshots")
      .createSignedUrl(screenshot_url, 300); // 5-minute expiry

    const imageUrl = signedUrlData?.signedUrl || screenshot_url;

    // Use Gemini to analyze the screenshot
    const aiResponse = await fetch(
      "https://ai.gateway.lovable.dev/v1/chat/completions",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            {
              role: "system",
              content:
                'You are an image verification assistant. You analyze Instagram screenshots to determine if the user is following a specific account. Look for the "A seguir" (Following) button or "Following" button in the screenshot. Respond ONLY with a JSON object: {"following": true} or {"following": false}. Nothing else.',
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text:
                    'Analyze this Instagram screenshot. Is the user following the account "restaurante_monte_grande"? Look for the "A seguir" or "Following" button which indicates they are following. Reply only with JSON.',
                },
                {
                  type: "image_url",
                  image_url: { url: imageUrl },
                },
              ],
            },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "verify_follow",
                description:
                  "Verify if the user is following the Instagram account based on the screenshot",
                parameters: {
                  type: "object",
                  properties: {
                    following: {
                      type: "boolean",
                      description:
                        'Whether the screenshot shows the user is following (has "A seguir" or "Following" button)',
                    },
                    confidence: {
                      type: "string",
                      enum: ["high", "medium", "low"],
                      description: "Confidence level of the verification",
                    },
                  },
                  required: ["following", "confidence"],
                  additionalProperties: false,
                },
              },
            },
          ],
          tool_choice: {
            type: "function",
            function: { name: "verify_follow" },
          },
        }),
      },
    );

    if (!aiResponse.ok) {
      const errText = await aiResponse.text();
      console.error("AI gateway error:", aiResponse.status, errText);
      // On AI failure, set to pending for manual review
      return jsonResponse(req, { status: "pending", reason: "AI verification unavailable" }, 200);
    }

    const aiData = await aiResponse.json();
    const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
    let following = false;

    if (toolCall?.function?.arguments) {
      try {
        const args = JSON.parse(toolCall.function.arguments);
        following = args.following === true;
      } catch {
        console.error("Failed to parse AI response");
      }
    }

    const newStatus = following ? "approved" : "rejected";
    const pointsToAward = following ? 10 : 0;

    // Update claim - only if still pending (prevents race condition / double-award)
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: updatedClaim } = await supabase
      .from("follow_claims")
      .update({
        status: newStatus,
        points_awarded: pointsToAward,
        reviewed_at: new Date().toISOString(),
        screenshot_url: "verified",
      })
      .eq("id", claim_id)
      .eq("user_id", user.id)
      .eq("status", "pending")
      .select("id")
      .maybeSingle();

    // If no row was updated, the claim was already processed
    if (!updatedClaim) {
      return jsonResponse(req, { status: "already_processed", following }, 200);
    }

    // Delete the screenshot from storage
    const { data: files } = await supabase.storage
      .from("follow-screenshots")
      .list(user.id);

    if (files && files.length > 0) {
      const paths = files.map((f: { name: string }) => `${user.id}/${f.name}`);
      await supabase.storage.from("follow-screenshots").remove(paths);
    }

    if (following) {
      // Award points
      const { data: profile } = await supabase
        .from("profiles")
        .select("total_points")
        .eq("user_id", user.id)
        .single();

      if (profile) {
        await supabase
          .from("profiles")
          .update({ total_points: (Number(profile.total_points) || 0) + 10 })
          .eq("user_id", user.id);
      }

      // Log transaction
      await supabase.from("transactions").insert({
        user_id: user.id,
        amount: 0,
        points_earned: 10,
        type: "follow",
        description: "Instagram follow — 10 pts",
      });
    }

    return jsonResponse(req, { status: newStatus, following }, 200);
  } catch (e) {
    console.error("verify-follow error:", e);
    return jsonResponse(req, { error: "An unexpected error occurred" }, 500);
  }
});
